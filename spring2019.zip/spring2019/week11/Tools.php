
<?php
    require_once('Product.php');
    class Tools extends Product
    {
        protected $shipper;
        protected $weight;
        protected $title;
        protected $description;
        protected $price;
        

        public function setTitle($title)
        {
            $this->title = $title;
        }
        public function getTitle()
        {
            return $this->title;
        }
        public function setDescription($description)
        {
            $this->description = $description;
        }
        public function getDescription()
        {
            return $this->description;
        }
        public function setPrice($price)
        {
            $this->price = $price;
        }
        public function getPrice()
        {
            return $this->price;
        }
        public function setShipper($shipper)
        {
            $this->shipper = $shipper;
        }
        public function getShipper()
        {
            return $this->shipper;
        }
        public function setWeight($weight)
        {
            $this->weight = $weight;
        }
        public function getWeight()
        {
            return $this->weight;
        }
        public function displayProduct()
        {
            echo "Tool Details <br/>";
            echo "Title: $this->title<br/>";
            echo "Desctiption: $this->description<br/>";
            echo "Price: $this->price<br/>";
            echo "Shipper: $this->shipper<br/>";
            echo "Weight: $this->weight<br/><br/>";
        }
        public function insertDB($dbc)
        {
            $query = "INSERT INTO product(title, description, price, shipper, weight)".
                "VALUES ('$this->title','$this->description','$this->price','$this->shipper','$this->weight')";
            mysqli_query($dbc, $query)
            or die('Error querying INSERT database');
        }
    }
    
