<html lang="en">
<head>
   
</head>
    
        <form method="post">

            <label> Pick type of your product<br/><br/></label>
             <select id="selectType" name="type">
                <option>Product</option>
				<option value="tools">Tools</option>
				<option value="electronics">Electronics</option>
				<option value="general">Generic</option>
			</select>
            <input type="submit" value="Submit" name="submit"/>
        </form>
        
        
<?php
    
    require_once('Product.php');
    require_once('Tools.php');
    require_once('Electronics.php');
    
    $allProduct = new Product();
    $allTools = new Tools();
    $allElectronics = new Electronics();
    


    if (isset($_POST['submit'])) 
    {
        $type = ($_POST['type']);
        echo "You entered: ". $type;
        
        if ($type == "tools")
        {
            ?>
            
            <form method="post">
            <label> Enter Tools information<br/><br/></label>
                <label><br/>Title: <br/></label>
                <input type="text" name="title" value size='20' />
                <label><br/>Description: <br/></label>
                <input type="text" name="description" value size='50' />
                <label><br/>Price: <br/></label>
                <input type="text" name= "price" value size='5' />
                <label><br/>Shipper: <br/></label>
                <input type="text" name="shipper" value size='20' />
                <label><br/>Weight: <br/></label>
                <input type="text" name="weight" value size='20' />
                <br/><br/><br/>
			
            <input type="submit" value="Submit" name="submitTools"/>
        </form>  
            <?php
        }
        if ($type == "electronics")
        {
            ?>
            
            <form method="post">
            <label> Enter Electronics information<br/><br/></label>
                <label><br/>Title: <br/></label>
                <input type="text" name="title" value size='20' />
                <label><br/>Description: <br/></label>
                <input type="text" name="description" value size='50' />
                <label><br/>Price: <br/></label>
                <input type="text" name= "price" value size='5' />
                <label><br/>Recyclable: </label>
                <select name="recyclable">
                    <option value="y">Yes</option>
                    <option value="n">No</option>
                </select>
                <br/>
                <br/>
			
            <input type="submit" value="Submit" name="submitElectronics"/>
        </form>  
            <?php
        }
        if ($type == "general")
        {
            ?>
            
            <form method="post">
                <label> Enter Genaric information</label>
                    <label><br/>Title: <br/></label>
                    <input type="text" name="title" value size='20' />
                    <label><br/>Description: <br/></label>
                    <input type="text" name="description" value size='50' />
                    <label><br/>Price: <br/></label>
                    <input type="text" name= "price" value size='5' />
                    <br/>
                    <br/>
    			
                <input type="submit" value="Submit" name="submitGeneral"/>
            </form>  
            <?php
        }

    }
            
    if (isset($_POST['submitGeneral'])) 
    {
        $allProduct->setTitle($_POST['title']);
        $allProduct->setDescription($_POST['description']);
        $allProduct->setPrice($_POST['price']);
        $allProduct->displayProduct();
        
        //Insert madlib story into DB
        $dbc = mysqli_connect('localhost' , 'root', '' , 'skfhlug')
                or die('Error connecting to MySQLserver');
                
        $allProduct->insertDB($dbc);
                
        //Close database
        mysqli_close($dbc);
    }
        if (isset($_POST['submitTools'])) 
    {
        $allTools->setTitle($_POST['title']);
        $allTools->setDescription($_POST['description']);
        $allTools->setPrice($_POST['price']);
        $allTools->setShipper($_POST['shipper']);
        $allTools->setWeight($_POST['weight']);
        $allTools->displayProduct();
        
        //Insert madlib story into DB
        $dbc = mysqli_connect('localhost' , 'root', '' , 'skfhlug')
                or die('Error connecting to MySQLserver');
                
        $allTools->insertDB($dbc);
                
        //Close database
        mysqli_close($dbc);
    }
        if (isset($_POST['submitElectronics'])) 
    {
        $allElectronics->setTitle($_POST['title']);
        $allElectronics->setDescription($_POST['description']);
        $allElectronics->setPrice($_POST['price']);
        $allElectronics->setRecyclable($_POST['recyclable']);
        $allElectronics->displayProduct();
        
        //Insert madlib story into DB
        $dbc = mysqli_connect('localhost' , 'root', '' , 'skfhlug')
                or die('Error connecting to MySQLserver');
                
        $allElectronics->insertDB($dbc);
                
        //Close database
        mysqli_close($dbc);
    }
            

    


?>
    </body>
</html>