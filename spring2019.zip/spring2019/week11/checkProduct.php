<?php
    function checkProduct()
    {
        var generalForm = document.getElementById("selectType");
        var tools = document.getElementById("tools");
        var electronics = document.getElementById("electronics");
        var general = document.getElementById("general");
    }
    
?>