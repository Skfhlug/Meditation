<?php
    require_once('Product.php');
    class Electronics extends Product
    {
        protected $recyclable;
        protected $title;
        protected $description;
        protected $price;
        

        public function setTitle($title)
        {
            $this->title = $title;
        }
        public function getTitle()
        {
            return $this->title;
        }
        public function setDescription($description)
        {
            $this->description = $description;
        }
        public function getDescription()
        {
            return $this->description;
        }
        public function setPrice($price)
        {
            $this->price = $price;
        }
        public function getPrice()
        {
            return $this->price;
        }
        public function setRecyclable($recyclable)
        {
            $this->recyclable = $recyclable;
        }
        public function getRecyclable()
        {
            return $this->recyclable;
        }
        
        public function displayProduct()
        {
            $recyclableStatus = $this->recyclable;
            
            echo "Electronics Details <br/>";
            echo "Title: $this->title<br/>";
            echo "Desctiption: $this->description<br/>";
            echo "Price: $this->price<br/>";
            if ($recyclableStatus == "y")
            {
                echo "Recyclable: Yes<br/><br/>";
            }
            else if ($recyclableStatus == "n")
            {
                echo "Recyclable: No<br/><br/>";
            }
        }
        
        public function insertDB($dbc)
        {
            $query = "INSERT INTO product(title, description, price, recyclable)".
                "VALUES ('$this->title','$this->description','$this->price','$this->recyclable')";
            mysqli_query($dbc, $query)
            or die('Error querying INSERT database');
        }
    }
    
?>