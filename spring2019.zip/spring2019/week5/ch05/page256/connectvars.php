<?php
  // Define database connection constants
  define('DB_HOST', 'www.guitarwars.net');
  define('DB_USER', 'admin');
  define('DB_PASSWORD', 'rockit');
  define('DB_NAME', 'gwdb');
?>
