<?php
  // Define database connection constants
  define('DB_HOST', 'www.guitarwars.net');
  define('DB_USER', 'ADMIN');
  define('DB_PASSWORD', 'Rockit');
  define('DB_NAME', 'gwdb');
?>
