<?php
    session_start();
    //Start the session
    require_once('startsession.php');
    
    //Insert the page header
    $page_title = 'Improving Meditation!';
    require_once('header.php');
    
    //require_once('appvars.php');
    require_once('connectvars.php');
    
    require_once('navmenu.php');
        
    
    // Connect to the database 
    
    
   ?>
<html>
    <body>
        
        <img src="images/howto.PNG" class="howto"/>
        
    </body> 
</html>
