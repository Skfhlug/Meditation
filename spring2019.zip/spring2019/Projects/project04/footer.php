<footer>
  <p>Posted by: Suparin Fhlug</p>
  <p>Contact information: <a href="mailto:someone@example.com">
  skfhlug@madisoncollege.edu</a>.</p>
</footer>