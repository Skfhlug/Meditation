<?php
    $items =array("milk", "eggs","cheese", "bacon");
    $person = array("name" => "joe", "email" => "job@gmail.com", "id => 1");
    
    foreach($person as $attr => $val)
    {
        printf("key: %s<br/> value: %s<br/><hr/>", $attr, $val);
    }
    $i =0;
    while ($i < count($items))
    {
        echo $item[$i];
        echo "<br/>'";
        $i++;
    }
    
    print "-------------------------";
    
    if((!empty($_GET)) || (!isset($_POST['formName'])) ||
        ($_POST['formName'] != 'sample8'))
        {
            die("Bad soure <br/>");
        }
        $name = $_POST['userName'];
        $phone = $_POST['userPhone'];
        $email = $_POST['userEmail'];
?>

    