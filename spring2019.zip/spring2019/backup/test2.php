<?php 
    $s1 = "Dan";
    $s2 = "Daniel";
    $s3 = "new york";
    $s4 = "New York";
    
    if ($s1 == $s2)
    {
        print"\n '$s1' equls '$s2'\n";
    }
    else 
    { 
        print"\n '$s1' not equls '$s2'\n";
    }
    print '<br/>';
    
    if (strcmp($s1, $s2)==0)
    {
        print"\n'$s1' equals '$s2' \n";
    }
    else
    {
        print "\n '$s1' not equals '$s2' \n";
    }
    
    print "----------------------<br/>";
    
    if (strcmp($s1, substr($s2, 0, 3)) == 0)
    {
        print "\n '$s1' equals '$s2" . substr($s2,0,3)
        ."'from '$s2'\n<br/>";
    }
    else 
    {
        print "\n '$s1' not equals '$s2" . substr($s2,0,3)
        ."'from '$s2'\n<br/>";
    }
    
    if(strcasecmp($s3, $s4) == 0) 
    {
        print "\n'$s3' equals '$s4' (case-insensitive)\n<br/>";
    }
    else
    {
        print "\n '$s3' not equals '$s4' (case-insensitive)\n<br/>";
    }
?>
    