<?php
    require_once('connectvars.php');
    
    if (!isset($_SERVER['PHP_AUTH_USER']) || !isset($_SERVER['PHP_AUTH_USER'])) 
    {  
        //The user/password weren't entered so send the authentication headers
        header('HTTP/1.1 401 Unauthorized');
        header('WWW-Authenticate: Basic realm="Mismatch"');
        exit('<h3>Mismatch</h3> Sorry, you must enter your username and pssword to log in and access ' . 'this page.');
    }
    
    //Connect to the database
    $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME)
        or die ('Error connect DB');
    
    //Grab the user-entered login data
    $user_username = mysqli_real_escape_string($dbc, trim($_SERVER['PHP_AUTH_USER']));
    $user_password = mysqli_real_escape_string($dbc, trim($_SERVER['PHP_AUTH_PW']));
    
    //Look up the username and password in the database
    $query = "SELECT user_id, username FROM mismatch_user WHERE username ='$user_username' AND ".
            "password = SHA('$user_password')";
    $data = mysqli_query($dbc, $query)
        or die ('Error query DB');
        
    if(mysqli_num_rows($data)==1) 
    {
        //The log-in is OK so set the ser ID and username variables
        $row = mysqli_fetch_array($data);
        $user_id = $row['user_id'];
        $username = $row['username'];
    }
    else
    {
        //the username/password are incorrect so send the authentication headers
        header('HTTP/1.1 401 Unautorized');
        header('WWW-Authenticate: Basic realm = "Mismatch"');
        exit('<h2> Mismatch</h2> Sorry, you must enter a valid username and password to login and '.
            'access the page.');
    }
    
    //Confirm the successful log-in
    echo ('<p class ="login"> You are logged in as ' . $username. '. </p>');
?>