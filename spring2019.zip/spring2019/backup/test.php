<html>
    <body>
        <!--<pre>-->
            <?php
            
            $var_a = 'Fred';
            $var_b = "Barney";
            
            print 'var_a = $var_a <br/>var_b = $var_b <br/>';
            echo "Var_b = $var_b";
                $c = -50;
                while ($c <100)
                {
                    $f = ($c * 1.8)+32;
                    print " C = $c --------- F = $f <br/>";
                    if ($f ==32 )
                    {
                        break;
                    }
                    $c +=5;
                }
                print "<br/>-------------------------------------<br/>";
                
                for ($c =-50 ; $c<100;$c++)
                {
                    $f =($c*1.8) +32;
                    print "c = $c ------------------- f= $f<br/>";
                }
            ?>
        <!--</pre>-->
    </body>
    
</html>
