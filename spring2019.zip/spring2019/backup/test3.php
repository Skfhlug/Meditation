<?php
    $color = 'red green orange blue';
    echo '$color is a '. gettype($color).'<br/>';


    $emp = array('name' => 'Jon', 'id' =>'23d4', 'job' => 'designer', 'zone' => 'IT');
    
    
    $color = explode(" ", $colors);
    echo 'After explode(): $color is an '. gettype($color);
    
    foreach($color as $value)
    {
        echo "$value <br/>";
    }
    
    echo "<hr>";
    
    foreach ($emp as $key => $value)
    {
        echo "emp[$key] => $value<br/>";
    }
?>