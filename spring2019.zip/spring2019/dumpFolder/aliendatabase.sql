-- MySQL dump 10.13  Distrib 5.5.57, for debian-linux-gnu (x86_64)
--
-- Host: 0.0.0.0    Database: aliendatabase
-- ------------------------------------------------------
-- Server version	5.5.57-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `aliens_abduction`
--

DROP TABLE IF EXISTS `aliens_abduction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aliens_abduction` (
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `when_it_happened` varchar(30) DEFAULT NULL,
  `how_long` varchar(30) DEFAULT NULL,
  `how_many` varchar(30) DEFAULT NULL,
  `alien_desciption` varchar(100) DEFAULT NULL,
  `what_they_did` varchar(100) DEFAULT NULL,
  `fang_spotted` varchar(10) DEFAULT NULL,
  `other` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aliens_abduction`
--

LOCK TABLES `aliens_abduction` WRITE;
/*!40000 ALTER TABLE `aliens_abduction` DISABLE KEYS */;
INSERT INTO `aliens_abduction` VALUES ('Sally','Jones',' 3 days ago','1 day','four','greeneith six tentacles','We just talked and played with a dog','yes','I may have seen your dog. Contact me.','sally@gregs-list.net'),('','','2 days go','5 hours','1','Big and white','Play with me','yes','He is so cute','sarah@gmail.com'),('Sam','','22 days go','11 hours','1','Big and white','He ate my food','yes','He is so big','Sam@gmail.com'),('Mickey','','now','5 hours','hundreds','Small dog','Look at them','yes','I logic to dogs','Mickey@gmail.com'),('Ann','','nothing','3 days ago','4','so cute','play with them','no','I love them','ann@gmail.com'),('Ann','','nothing','3 days ago','4','so cute','play with them','no','I love them','ann@gmail.com'),('Captain Jack','Sparrow','yesterday','4 days','3','green','Made me drink rum','yes','no','iAmCaptainJack@pirates.com'),('','','15 days ago','2 hours','3','Cute','Play','yes','He is a cute dog','adam@gmail.com'),('','','500 days ago','11hours','4','He is a bid dog','ran','yes','He is a cute dog','pink@gmail.com'),('','','500 days ago','11hours','4','He is a bid dog','ran','yes','He is a cute dog','pink@gmail.com'),('','','500 days ago','11hours','20','He is a bid dog','ran','yes','12452425','bbb@gmail.com'),('Tom','Tommy','500 days ago','11hours','20','dsfff','sdfsfdf','yes','aaaaaaaaaaa','Tommy@gmail.com'),('Suparin','Fhlug','Wisconsin','3 hours','22','White','Run','yes','dfdsffd','suparin.fhlug@gmail.com');
/*!40000 ALTER TABLE `aliens_abduction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-07 19:23:31
