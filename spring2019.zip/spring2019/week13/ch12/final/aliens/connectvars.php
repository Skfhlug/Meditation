<?php
  // Define database connection constants
  define('DB_HOST', 'data.aliensabductedme.com');
  define('DB_USER', 'owen');
  define('DB_PASSWORD', 'aliensrool');
  define('DB_NAME', 'aliendatabase');
?>
