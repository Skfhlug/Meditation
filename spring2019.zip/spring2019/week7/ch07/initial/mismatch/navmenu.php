<?php
    //Generate the navigation menu
    echo '<hr />';
    if (isset($_SESSION['username']))
    {
        echo '&#10084; <a href="index.php">Home</a><br />';
        echo '&#10084; <a href="viewprofile.php">View Profile</a><br />';
        echo '&#10084; <a href="editprofile.php">Edit Profile</a><br />';
        echo '&#10084; <a href="logout.php">Log out ('.$_SESSION['username']. ')</a><br />';
    }
    
    else
    {
        echo '<a href = "login.php">Log In</a> &#10084';
        echo '<a href = "signupTest.php">Sign Up</a> &#10084';
    }    
    echo '<hr/>';
?>