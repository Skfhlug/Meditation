-- MySQL dump 10.13  Distrib 5.5.57, for debian-linux-gnu (x86_64)
--
-- Host: 0.0.0.0    Database: skfhlug
-- ------------------------------------------------------
-- Server version	5.5.57-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `MadLibs`
--

DROP TABLE IF EXISTS `MadLibs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `MadLibs` (
  `noun` varchar(20) DEFAULT NULL,
  `verb` varchar(20) DEFAULT NULL,
  `adverb` varchar(20) DEFAULT NULL,
  `adjective` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `MadLibs`
--

LOCK TABLES `MadLibs` WRITE;
/*!40000 ALTER TABLE `MadLibs` DISABLE KEYS */;
INSERT INTO `MadLibs` VALUES ('a','b','c','d'),('u','w','x','y'),('sailor','sell','excellently','expert'),('air','eat','slowly','green'),('air','eat','slowly','green'),('car','show','faster','pretty'),('2','3','4','5'),('we','wef','we','we'),('we','wef','we','we'),('sdf','sdf','sdf','sdf'),('sailor','selllllllllllll','slowly','expert'),('Driver','drives','terribly','visibly'),('','','',''),('Home','eat','slowly','pretty'),('','','',''),('rabbit','jumps','poorly','horrible');
/*!40000 ALTER TABLE `MadLibs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fullname`
--

DROP TABLE IF EXISTS `fullname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fullname` (
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fullname`
--

LOCK TABLES `fullname` WRITE;
/*!40000 ALTER TABLE `fullname` DISABLE KEYS */;
INSERT INTO `fullname` VALUES ('Suparin','Fhlug'),('',''),('',''),('',''),('',''),('',''),('fgbggb','sgg'),('','');
/*!40000 ALTER TABLE `fullname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mismatch_user`
--

DROP TABLE IF EXISTS `mismatch_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mismatch_user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `join_date` datetime DEFAULT NULL,
  `first_name` varchar(32) DEFAULT NULL,
  `last_name` varchar(32) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `city` varchar(32) DEFAULT NULL,
  `state` varchar(2) DEFAULT NULL,
  `picture` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mismatch_user`
--

LOCK TABLES `mismatch_user` WRITE;
/*!40000 ALTER TABLE `mismatch_user` DISABLE KEYS */;
INSERT INTO `mismatch_user` VALUES (1,'','','2008-06-03 14:51:46','Sidney','Kelsow','F','1984-07-19','Tempe','AZ','sidneypic.jpg'),(2,'','','2008-06-03 14:52:09','Nevil','Johansson','M','1973-05-13','Reno','NV','nevilpic.jpg'),(3,'','','2008-06-03 14:53:05','Alex','Cooper','M','1974-09-13','Boise','ID','alexpic.jpg'),(4,'','','2008-06-03 14:58:40','Susannah','Daniels','F','1977-02-23','Pasadena','CA','susannahpic.jpg'),(5,'','','2008-06-03 15:00:37','Ethel','Heckel','F','1943-03-27','Wichita','KS','ethelpic.jpg'),(6,'','','2008-06-03 15:00:48','Oscar','Klugman','M','1968-06-04','Providence','RI','oscarpic.jpg'),(7,'','','2008-06-03 15:01:08','Belita','Chevy','F','1975-07-08','El Paso','TX','belitapic.jpg'),(8,'','','2008-06-03 15:01:19','Jason','Filmington','M','1969-09-24','Hollywood','CA','jasonpic.jpg'),(9,'','','2008-06-03 15:01:51','Dierdre','Pennington','F','1970-04-26','Cambridge','MA','dierdrepic.jpg'),(10,'','','2008-06-03 15:02:02','Paul','Hillsman','M','1964-12-18','Charleston','SC','paulpic.jpg'),(11,'','','2008-06-03 15:02:13','Johan','Nettles','M','1981-11-03','Athens','GA','johanpic.jpg'),(12,'jnettles','7936ee10da1d33b1','2019-03-05 15:57:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,'jimi','2aa36f17507f2c75df2e24aa63c7dabcaf86926e','2019-03-05 16:03:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,'anna','aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d','2019-03-07 14:29:02','Anna','Smith','F','2002-05-01','Madison','Wi','ethelpic.jpg'),(15,'Tina','f7ff9e8b7bb2e09b70935a5d785e0cc5d9d0abf0','2019-03-07 16:02:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,'Adam','f941e1206abd4a2d8889da67be10151f429d95dc','2019-03-07 18:37:44','Adam','Tony','M','2011-04-15','Madison','WI','alexpic.jpg'),(17,'Linda','4b971c383f88f081f787088db1cfe07f95a7c292','2019-03-07 18:56:55','Linda','Lucky','F','1899-11-24','Madison','WI','susannahpic.jpg'),(18,'Pinky','4dab5c90d5f74960afc1931810c453f2b029a145','2019-03-07 18:59:33','Pinky','Lucky','F','2000-08-14','Madison','WI','belitapic.jpg'),(19,'AA','801c34269f74ed383fc97de33604b8a905adb635','2019-03-07 19:01:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,'Lily','89a254a753cf0fe40eadd6b6c9f76a99d41b01c2','2019-03-07 19:05:25','Lily','Miller','F','1998-04-16','Madison','WI','dierdrepic.jpg'),(21,'kitty','95d79f53b52da1408cc79d83f445224a58355b13','2019-03-07 19:30:20','Hello','Kitty','F','1995-01-01','Hollywood','CA','hellokitty.jpg');
/*!40000 ALTER TABLE `mismatch_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-07 19:42:25
