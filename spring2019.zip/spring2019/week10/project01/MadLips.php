<?php
    $result;
    class MadLips
    {
        private $noun; //house, chair, car
        private $verb; //Eat, run, drive
        private $adverb; //fastly, slowly
        private $adjective; //pretty, big
        
        //Getters
        public function getNoun()
        {
            return $this->noun;
        }
        public function getVerb()
        {
            return $this->verb;
        }
        public function getAdverb()
        {
            return $this->adverb;
        }
        public function getAdjective()
        {
            return $this->adjective;
        }
        
        //Setter
        public function setNoun($noun)
        {
            $this->noun = $noun;
        }
        public function setVerb($verb)
        {
            $this->verb = $verb;
        }
        public function setAdverb($adverb)
        {
            $this->adverb = $adverb;
        }
        public function setAdjective($adjective)
        {
            $this->adjective = $adjective;
        }
        
        public function insertDB($dbc)
        {
            $query = "INSERT INTO MadLibs(noun, verb, adverb, adjective)".
                "VALUES ('$this->noun','$this->verb','$this->adverb','$this->adjective')";
            mysqli_query($dbc, $query)
            or die('Error querying INSERT database'); 
        
        }

        public function concateStory()
        {
            //Display current answer sentence and word that user enter
            echo '<br /> Here is your ANSWER... hahaha ...<br />';
            echo 'You ' . $this->adverb;
            echo ' ' . $this->verb;
            echo ' like a(n) ' . $this->adjective;
            echo ' ' . $this->noun;
            echo '. <br /><br />How funny is that?<br />';
            echo '-----------------------------------------';
        }
        
        public function getResult($dbc)
        {           
            $query = "SELECT * FROM MadLibs";
            $result = mysqli_query($dbc, $query)
                or die('Error querying select data from database');
            //$this->result = $result;
            
            return $result;
        }
        
        public function displayhistory($result)
        {   
            while ($row = mysqli_fetch_array($result)) 
            {
                $noun = $row['noun'];
                $verb = $row['verb'];
                $adverb = $row['adverb'];
                $adverb = $row['adjective'];
                
                echo '<br /><tr>You <td> ' . $adverb;
                echo '</td><td> ' . $verb;
                echo '</td> like  a(n) <td>' . $adjective;
                echo '</td><td> ' . $noun . '. </td></tr>';
            }
        }

    }
?>