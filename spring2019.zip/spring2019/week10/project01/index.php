<html lang="en">
<head>
    <title>MadLips</title>
</head>
    <body style="background-color: #ffe6e6;padding: 25px 50px 75px 100px;">
    <h2 style="color:#ff6666;">Enjoy the MadLips by SUPARIN</h2>
        <form action="index.php" method="post">
            <label style="color:#ff6666;" for="subject">Enter a noun:</label>
            <input type="text" id="noun" name="noun" /><br /><br />
            <label style="color:#ff6666;" for="subject">Enter a verb:</label>
            <input type="text" id="verb" name="verb" /><br /><br />
            <label style="color:#ff6666;" for="subject">Enter a adverb:</label>
            <input type="text" id="adverb" name="adverb" /><br /><br />
            <label style="color:#ff6666;" for="subject">Enter a adjective:</label>
            <input type="text" id="adjective" name="adjective" /><br /><br />
            <input type="submit" value="submit" name="submit" />
        </form>
<?php
    require_once('MadLips.php');
    
    $madlip_game = new MadLips();


    if (isset($_POST['submit'])) 
    {
        //Setting words by using method
        $madlip_game->setNoun($_POST['noun']);
        $madlip_game->setVerb($_POST['verb']);
        $madlip_game->setAdverb($_POST['adverb']);
        $madlip_game->setAdjective($_POST['adjective']);


        //Insert madlib story into DB
        $dbc = mysqli_connect('localhost' , 'root', '' , 'skfhlug')
                or die('Error connecting to MySQLserver');
                
        $madlip_game->insertDB($dbc);


        $madlip_game->concateStory(); //Display the lastest inputs
        $madlip_game->getResult($dbc);
        
        $result = $madlip_game->getResult($dbc);
        $madlip_game->displayHistory($result); // Display the stories
        
        //Close database
        mysqli_close($dbc);
    }

?>
    </body>
</html>